# espn-headlines lambda micro server
Retrieves the top headlines for espn.com.

## Build

        build-scripts/build.sh

## Invoke Locally

        build-scripts/invoke-local.sh

## Deploy to AWS

        build-scripts/deploy.sh
