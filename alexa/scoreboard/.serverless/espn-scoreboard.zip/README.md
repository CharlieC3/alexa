# espn-scoreboard lambda micro service
Retrieves the scoreboards from espn.com

## Build

        build-scripts/build.sh

## Invoke Locally

        build-scripts/invoke-local.sh

## Deploy to AWS

        build-scripts/deploy.sh
